package testing;

import java.io.*;
import java.util.*;
import Modelo.*;
import Persistencia.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoadServicioTest {
    public static void main(String[] args) {
        testUpdateServicio();
        testCargarServicio();
        testSalvarServicio();
        testRemoveServicio();
        testDeleteFile();
        testServiciosACargar();
        testSalvarServiciosDoc();
    }
    
    @Test
    public static void testUpdateServicio() {
        File f = new File("data/servicios.txt");
        HashMap<String, Integer> map = LoaderSaver.updateServicio(f);
    }
    
    @Test
    public static void testCargarServicio() {
        String file = "nombreServicio";
        HashMap<String, Integer> map = LoaderSaver.cargarServicio(file);
    }
    
    @Test
    public static void testSalvarServicio() {
        HashMap<String, Integer> map = new HashMap<>();
        String file = "nombreServicio";
        LoaderSaver.salvarServicio(map, file);
    }
    
    @Test
    public static void testRemoveServicio() {
        String nombreServicio = "nombreServicio";
        LoaderSaver.removeServicio(nombreServicio);
    }
    
    @Test
    public static void testDeleteFile() {
        File f = new File("data/servicios.txt");
        LoaderSaver.deleteFile(f);
    }
    
    @Test
    public static void testServiciosACargar() {
        String[] servicios = LoaderSaver.serviciosACargar();
    }

    @Test
    public static void testSalvarServiciosDoc() {
        HashMap<String, Servicio> servicios = new HashMap<>();
        LoaderSaver.salvarServiciosDoc(servicios);
    }
}

