package testing;

import java.io.*;
import java.util.*;
import Modelo.*;
import Persistencia.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoadHabitacionesTest 
{
	@BeforeEach
    public static void main(String[] args) {
        testUpdateHabitaciones();
        testCargarHabitaciones();
        testSalvarHabitaciones();
    }
	
	@Test
    public static void testUpdateHabitaciones() {
        File f = new File("data/habitaciones.txt");
        ArrayList<Habitacion> habitaciones = LoaderSaver.updateHabitaciones(f);
    }
	
	@Test
    public static void testCargarHabitaciones() {
        ArrayList<Habitacion> habitaciones = LoaderSaver.cargarHabitaciones();
    }
	
	@Test
    public static void testSalvarHabitaciones() {
        ArrayList<Habitacion> habitaciones = new ArrayList<>();
        LoaderSaver.salvarHabitaciones(habitaciones);
    }
}
