package testing;

import java.io.*;
import java.time.*;
import java.util.*;
import Modelo.*;
import Persistencia.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class FacturaTest {
    public static void main(String[] args) {
        testCargarFacturas();
        testGetContadorFactura();
        testSalvarFacturas();
    }
    
    @Test
    public static void testCargarFacturas() {
        ArrayList<String> facturas = LoaderSaver.cargarFacturas();
    }

    @Test
    public static void testGetContadorFactura() {
        ArrayList<String> facturas = new ArrayList<>();
        int contador = LoaderSaver.getContadorFactura(facturas);
    }

    @Test
    public static void testSalvarFacturas() {
        ArrayList<String> facturas = new ArrayList<>();
        LoaderSaver.salvarFacturas(facturas);
    }
}

