package testing;

import java.io.*;
import java.time.*;
import java.util.*;
import Modelo.*;
import Persistencia.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoadConsumoTest {
    public static void main(String[] args) {
        testCargarReservas();
        testSalvarReservas();
    }
    
    @Test
    public static void testCargarReservas() {
        ArrayList<Habitacion> allHabitaciones = new ArrayList<>();
        HashMap<String, Servicio> allServicios = new HashMap<>();
        ArrayList<ReservaEstadia> reservas = LoaderSaver.cargarReservas(allHabitaciones, allServicios);
    }
    
    @Test
    public static void testSalvarReservas() {
        ArrayList<ReservaEstadia> reservas = new ArrayList<>();
        LoaderSaver.salvarReservas(reservas);
    }
}

