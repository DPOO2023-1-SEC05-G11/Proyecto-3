package Modelo;

import java.util.*;

public class ReporteCreator {
    private static Map<String, Integer> salesByProduct;
    private static List<Double> invoiceValues;

    public ReporteCreator() {
        salesByProduct = new HashMap<>();
        invoiceValues = new ArrayList<>();
    }

    public static void generarReporteVentasPorProducto(Consumo consumo) {
        String producto = consumo.getServicio().getName();
        int cantidad = 1;
        double valorTotal = consumo.getPrecioTotal();

        if (salesByProduct.containsKey(producto)) {
            int totalCantidad = salesByProduct.get(producto) + cantidad;
            salesByProduct.put(producto, totalCantidad);
        } else {
            salesByProduct.put(producto, cantidad);
        }

        System.out.println("Ventas por producto (en cantidades y en valor total):");
        System.out.println("Producto: " + producto);
        System.out.println("Cantidad: " + cantidad);
        System.out.println("Valor total: " + valorTotal);
        System.out.println();
    }
    
    public static void generarReporteValorFacturas(Factura factura) {
        double valorFactura = factura.getPrecioTotal();

        invoiceValues.add(valorFactura);

        System.out.println("Valor de las facturas a lo largo del tiempo:");
        System.out.println("Valor de la factura: " + valorFactura);
        System.out.println();
    }
    
    public static void generarReporteRelacionConsumoValorNoche(Consumo consumo, double valorNoche) {
        double valorConsumo = consumo.getPrecioTotal();
        double relacion = valorConsumo / valorNoche;

        System.out.println("Relación entre el valor de los consumos en el restaurante y el valor que se paga por noche por habitación:");
        System.out.println("Valor del consumo: " + valorConsumo);
        System.out.println("Valor por noche por habitación: " + valorNoche);
        System.out.println("Relación: " + relacion);
        System.out.println();
    }
    
    public void generarReporteConsumosTotalesRestaurante(List<Consumo> consumos) {
        System.out.println("Reporte de Consumos Totales del Restaurante:");

        Map<String, Integer> totalPorProducto = new HashMap<>();
        double valorTotalConsumos = 0;

        for (Consumo consumo : consumos) {
            String producto = consumo.getServicio().getName();
            int cantidad = 1;
            double valorTotal = consumo.getPrecioTotal();

            if (totalPorProducto.containsKey(producto)) {
                int totalCantidad = totalPorProducto.get(producto) + cantidad;
                totalPorProducto.put(producto, totalCantidad);
            } else {
                totalPorProducto.put(producto, cantidad);
            }

            valorTotalConsumos += valorTotal;
        }

        for (String producto : totalPorProducto.keySet()) {
            int totalCantidad = totalPorProducto.get(producto);
            System.out.println("Producto: " + producto);
            System.out.println("Cantidad Total: " + totalCantidad);
            System.out.println();
        }

        System.out.println("Valor Total de los Consumos: " + valorTotalConsumos);
    }
    
    public static void generarReporteOcupacionHabitacionesPorTipo(List<Habitacion> habitaciones) {
        System.out.println("Reporte de Ocupación de Habitaciones por Tipo:");

        Map<String, Integer> ocupacionPorTipo = new HashMap<>();

        for (Habitacion habitacion : habitaciones) {
            String tipoHabitacion = habitacion.getTipo();

            if (ocupacionPorTipo.containsKey(tipoHabitacion)) {
                int ocupacionTipo = ocupacionPorTipo.get(tipoHabitacion) + 1;
                ocupacionPorTipo.put(tipoHabitacion, ocupacionTipo);
            } else {
                ocupacionPorTipo.put(tipoHabitacion, 1);
            }
        }

        for (String tipoHabitacion : ocupacionPorTipo.keySet()) {
            int ocupacionTipo = ocupacionPorTipo.get(tipoHabitacion);
            System.out.println("Tipo de Habitación: " + tipoHabitacion);
            System.out.println("Cantidad de Habitaciones Ocupadas: " + ocupacionTipo);
            System.out.println();
        }
    }

}

