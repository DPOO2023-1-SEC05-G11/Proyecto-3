/**
 * 
 */
/**
 * @author SONY
 *
 */
module Proyecto2_PMS {
	requires java.desktop;
}