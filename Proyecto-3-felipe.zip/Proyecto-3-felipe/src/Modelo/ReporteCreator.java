package Modelo;

import org.jfree.*;


public class ReporteCreator {
    public void generarReporteVentasPorProducto() {

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(100, "Productos", "Producto 1");
        dataset.addValue(200, "Productos", "Producto 2");
        dataset.addValue(150, "Productos", "Producto 3");


        JFreeChart chart = ChartFactory.createBarChart(
                "Ventas por Producto",
                "Producto",
                "Cantidad",
                dataset
        );

        ChartFrame frame = new ChartFrame("Reporte de Ventas por Producto", chart);
        frame.pack();
        frame.setVisible(true);
    }

    public void generarReporteValorFacturas() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(500, "Facturas", "Enero");
        dataset.addValue(800, "Facturas", "Febrero");
        dataset.addValue(1200, "Facturas", "Marzo");

        JFreeChart chart = ChartFactory.createLineChart(
                "Valor de las Facturas",
                "Mes",
                "Valor",
                dataset
        );

        ChartFrame frame = new ChartFrame("Reporte de Valor de Facturas", chart);
        frame.pack();
        frame.setVisible(true);
    }

    public void generarReporteRelacionConsumos() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(500, "Relación", "Día 1");
        dataset.addValue(600, "Relación", "Día 2");
        dataset.addValue(700, "Relación", "Día 3");

        JFreeChart chart = ChartFactory.createBarChart(
                "Relación Consumos vs Pago por Noche",
                "Día",
                "Valor",
                dataset
        );

        ChartFrame frame = new ChartFrame("Reporte de Relación Consumos vs Pago por Noche", chart);
        frame.pack();
        frame.setVisible(true);
    }
}
